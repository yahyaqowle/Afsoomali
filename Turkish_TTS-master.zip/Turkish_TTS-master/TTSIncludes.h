/** 
 * Used for common includes.
 */
#ifndef _TTS_INCLUDES_H
#define _TTS_INCLUDES_H

#include <windows.h>
#include <Mmsystem.h>
#include <stdio.h>
#include <stdlib.h>
#include <TCHAR.H>
#include <sys/types.h>
#include <sys/stat.h>
#include <string>
#include "TTSError.h"

#include <locale>
#include <iostream>
#include <vector>
#include <fstream>

using namespace std;
#endif