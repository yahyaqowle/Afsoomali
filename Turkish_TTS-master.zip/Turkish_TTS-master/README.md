"Turkish TTS" 

To test:
C:...\>TTS.exe

type in
	merhaba

hear it

Note: You will see diagnostic messages during the execution. The output will be 
Loaded 28 abbreviation(s)
Loaded 25 exception(s)
totalSize = 7565688
header.riffChunk.packageLength = 7565644
header.dataChunk.dataLength = 7565644
merhaba

Format: XOXXOXO
Syllables: mer-ha-ba
content=mer-ha-ba
OK - producer
token: mer
token: ha
token: ba
Offset  3700758    Size:   4002

Offset  2085094    Size:   2648

Offset  251154    Size:   1928

OK - consumer